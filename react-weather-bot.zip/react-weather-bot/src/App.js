//Importing required libraries.
import React, { Component } from 'react';
    import Pusher from 'pusher-js';
    import './App.css';

    //Inheriting from component class.
    class App extends Component {
      constructor(props) {
        super(props);
        this.state = {
          userMessage: '',
          conversation: [],
        };
      }

      //Mounting from pusher api.
      componentDidMount() {
        const pusher = new Pusher('fdb0db858fb34f1851c3', {
          cluster: 'eu',
          encrypted: true,
        });

        //Biding resposes for the bot
        const channel = pusher.subscribe('bot');
        channel.bind('bot-response', data => {
          const msg = {
            text: data.message,
            user: 'ai',
          };
          this.setState({
            conversation: [...this.state.conversation, msg],
          });
        });
      }

      //Getting user message in case it changes.
      handleChange = event => {
        this.setState({ userMessage: event.target.value });
      };

      //Getting data when text is submited
      handleSubmit = event => {
        event.preventDefault();
        if (!this.state.userMessage.trim()) return;

        const msg = {
          text: this.state.userMessage,
          user: 'human',
        };

        this.setState({
          conversation: [...this.state.conversation, msg],
        });

        fetch('http://localhost:5000/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: this.state.userMessage,
          }),
        });

        this.setState({ userMessage: '' });
      };

      //Rendering text onto interface (chat window).
      render() {
        const ChatBubble = (text, i, className) => {
          return (
            <div key={`${className}-${i}`} className={`${className} chat-bubble`}>
              <span className="chat-content">{text}</span>
            </div>
          );
        };

        const chat = this.state.conversation.map((e, index) =>
          ChatBubble(e.text, index, e.user)
        );

        //Returning the main values for the chatbox.
        return (
          <div>
            <div className="header-box">
              <h1>Outfit Check Chatbot</h1>
            </div>
            <div className="chat-window">
              <div className="conversation-view">{chat}</div>
              <div className="message-box">
                <form onSubmit={this.handleSubmit}>
                  <input
                    value={this.state.userMessage}
                    onInput={this.handleChange}
                    className="text-input"
                    type="text"
                    autoFocus
                    placeholder="Type your message and hit Enter to send"
                  />
                </form>
              </div>
            </div>
          </div>
        );
      }
    }

    export default App;